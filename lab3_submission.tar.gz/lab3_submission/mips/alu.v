//=============================================================================
// EE180 Lab 3
//
// MIPS CPU Module. Contains the five stages in the single-cycle MIPS CPU.
//=============================================================================

`include "mips_defines.v"

module alu (
    input [3:0] alu_opcode,
    input [31:0] alu_op_x,
    input [31:0] alu_op_y,
    output reg [31:0] alu_result,
    output alu_op_y_zero,
    output wire alu_overflow
);



//Questions
// - How to load modules?
// - can I copy fpga.img directly from farmshare ssh to zedboard ssh?
// - what is your_prog.hex and app.hex?
// - is baxter avi already on zedboard?

// - what FPS do we want for the video, and how to check what it is?


// add   - DONE, VERIFIED with more robust test
// addi  - DONE, VERIFIED with more robust test
// addiu - DONE, VERIFIED with more robust test
// addu  - DONE, VERIFIED with more robust test
// and   - DONE, VERIFIED with more robust test
// andi  - DONE, VERIFIED with more robust test
// beq   - DONE, VERIFIED 
// bgez  - DONE, VERIFIED 
// bgtz  - DONE, VERIFIED 
// blez  - DONE, VERIFIED 
// bltz  - DONE, VERIFIED 
// bne   - DONE, VERIFIED 
// j     - DONE, VERIFIED
// jal   - DONE, VERIFIED
// jalr  - DONE, VERIFIED
// jr    - DONE, VERIFIED
// lb    - DONE, VERIFIED
// lbu   - DONE, VERIFIED
// lh    - DONE, VERIFIED
// ll    - DONE, VERIFIED 
// lui   - DONE, VERIFIED
// lw    - DONE, VERIFIED
// movn  - DONE, VERIFIED
// movz  - DONE, VERIFIED
// mul   - DONE, VERIFIED
// nor   - DONE, VERIFIED
// or    - DONE, VERIFIED
// ori   - DONE, VERIFIED 
// sb    - DONE, VERIFIED
// sc    - DONE, VERIFIED
// sh    - DONE, VERIFIED
// sll   - DONE, VERIFIED
// sllv  - DONE, VERIFIED
// slt   - DONE, VERIFIED
// slti  - DONE, VERIFIED with more robust test
// sltiu - DONE, VERIFIED with more robust test
// sltu  - DONE, VERIFIED with more robust test
// sra   - DONE, VERIFIED with more robust test
// srav  - DONE, VERIFIED
// srl   - DONE, VERIFIED with more robust test
// srlv  - DONE, VERIFIED
// sub   - DONE, VERIFIED with more robust test
// subu  - DONE, VERIFIED with more robust test
// sw    - DONE, VERIFIED
// xor   - DONE, VERIFIED with more robust test
// xori  - DONE, VERIFIED with more robust test


//******************************************************************************
// Shift operation: ">>>" will perform an arithmetic shift, but the operand
// must be reg signed, also useful for signed vs. unsigned comparison.
//******************************************************************************
    wire signed [31:0] alu_op_x_signed = alu_op_x;
    wire signed [31:0] alu_op_y_signed = alu_op_y;

//******************************************************************************
// ALU datapath
//******************************************************************************

    always @* begin
        case (alu_opcode)
            // PERFORM ALU OPERATIONS DEFINED ABOVE
            `ALU_ADD:   alu_result = alu_op_x_signed + alu_op_y_signed;  //EDITED BY GRAHAM, previously unsigned
            `ALU_ADDU:  alu_result = alu_op_x + alu_op_y;
            `ALU_AND:   alu_result = alu_op_x & alu_op_y;
            `ALU_OR:    alu_result = alu_op_x | alu_op_y;
            `ALU_SUB:   alu_result = alu_op_x_signed - alu_op_y_signed; //EDITED BY GRAHAM, previously unsigned
            `ALU_SUBU:  alu_result = alu_op_x - alu_op_y;
            `ALU_SLTU:  alu_result = alu_op_x < alu_op_y;
            `ALU_SLT:   alu_result = alu_op_x_signed < alu_op_y_signed;
            `ALU_SRL:   alu_result = alu_op_y >> alu_op_x;       // shift operations are Y >> X
            `ALU_SLL:   alu_result = alu_op_y << alu_op_x;
            `ALU_XOR:   alu_result = alu_op_x ^ alu_op_y;             //ADDED BY GRAHAM
            `ALU_SRA:   alu_result = alu_op_y_signed >>> alu_op_x;      //ADDED BY GRAHAM
            `ALU_NOR:   alu_result = ~(alu_op_x | alu_op_y);          //ADDED BY GRAHAM
            `ALU_MUL:   alu_result = alu_op_x_signed * alu_op_y_signed;      //ADDED BY GRAHAM

            `ALU_PASSX: alu_result = alu_op_x;
            `ALU_PASSY: alu_result = alu_op_y;
            default:    alu_result = 32'hxxxxxxxx;   // undefined
        endcase
    end

    wire alu_neg = alu_result[31];
    wire x_neg = alu_op_x[31];
    wire y_neg = alu_op_y[31];

    wire add_check = alu_opcode == `ALU_ADD;
    wire sub_check = alu_opcode == `ALU_SUB;

    wire add_pos_over = &{~x_neg, ~y_neg, alu_neg}; // postive + positive = negative
    wire add_neg_over = &{x_neg, y_neg, ~alu_neg}; // negative + negative = positive
    wire sub_pos_over = &{~x_neg, y_neg, alu_neg}; // positive - negative = negative
    wire sub_neg_over = &{x_neg, ~y_neg, ~alu_neg}; // negative - positive = positive

    assign alu_op_y_zero = ~|{alu_op_y};

    assign alu_overflow = |{add_check & (add_pos_over | add_neg_over),
                            sub_check & (sub_pos_over | sub_neg_over)};

endmodule
